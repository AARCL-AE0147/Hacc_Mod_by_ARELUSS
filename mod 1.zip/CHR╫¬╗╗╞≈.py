#coding:utf-8
text = "hello kali"
output = ""
for i in range(len(text)):
    output +="CHR(%s)" % ord(text[i])
    if i<len(text)-1:
        output +="."

print (output)
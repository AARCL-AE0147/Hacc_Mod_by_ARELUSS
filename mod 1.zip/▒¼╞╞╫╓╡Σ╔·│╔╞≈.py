import itertools as its
import sys
A=sys.argv[1]

word="ARELUSS123456"
#portduct很重要 因为密码长度是6 重复次数是6
f=open(A,"w")
pot=its.product(word,repeat=6)

for i in pot:
    
    

